for i in range(10,0,-1):
    print('* '*i,'\n')
for j in range(10):
    print('* '*j,'\n')
for h in range(10):
    print('  '*(9-h),'* '*(h+1),'\n')