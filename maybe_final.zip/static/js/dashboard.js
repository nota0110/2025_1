// 전역 변수 - hisnet로그인 정보 저장용
let currentLoginData = null;

// 학부 아이콘 매핑
const deptIcons = {
  "일반공지": "📢", "글로벌리더십": "🌍", "국제어문": "🔤",
  "경영경제": "💼", "법학부": "⚖️", "커뮤니케이션": "📡",
  "상담복지": "🤝", "생명과학": "🧬", "공간환경시스템": "🏗️",
  "전산전자": "💻", "콘텐츠융합디자인": "🎨", "기계제어": "⚙️",
  "ICT창업학부": "🚀", "언어교육원": "📚", "창의융합교육원": "💡",
  "AI융합교육원": "🤖"
};

// 유틸리티 함수들
function fadeInCard(id) {
  const el = document.getElementById(id);
  el.style.display = "block";
  setTimeout(() => el.classList.add("show"), 10);
}

function showLoading() { //로딩중
  document.getElementById("loading-spinner").classList.add("show");
}

function hideLoading() { //로딩 끝
  document.getElementById("loading-spinner").classList.remove("show");
}

function showToast(message, isError = false) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.className = isError ? 'toast error show' : 'toast show';
  
  setTimeout(() => {
    toast.classList.remove('show');
  }, 3000);
}

// 비밀번호 토글
function togglePassword() {
  const passwordInput = document.getElementById("password");
  const toggleIcon = document.querySelector(".toggle-password");
  
  if (passwordInput.type === "password") {
    passwordInput.type = "text";
    toggleIcon.textContent = "🙈";
  } else {
    passwordInput.type = "password";
    toggleIcon.textContent = "👁️";
  }
}

// 날씨 & 뉴스 불러오기
async function loadWeatherNews() {
  const weatherKey = document.getElementById("weather-api").value.trim();
  const gnewsKey = document.getElementById("gnews-api").value.trim();
  const openaiKey = document.getElementById("openai-api").value.trim();

  if (!weatherKey || !gnewsKey || !openaiKey) {
    showToast("모든 API 키를 입력해주세요.", true);
    return;
  }

  showLoading();

  try {
    // 실제 기상청 API로 날씨 정보 가져오기
    await loadWeather(weatherKey);
    
    // 뉴스 정보 가져오기
    await loadNews(gnewsKey, openaiKey);

    showToast("날씨 & 뉴스를 성공적으로 불러왔습니다!");

  } catch (error) {
    console.error("날씨/뉴스 로딩 실패:", error);
    showToast("날씨 & 뉴스를 불러오는 데 실패했습니다.", true);
  } finally {
    hideLoading();
  }
}

// 실제 기상청 API 호출
async function loadWeather(key) {
  const nx = 102, ny = 94; // 포항 좌표
  const now = new Date();
  const dateStr = now.toISOString().slice(0, 10).replace(/-/g, '');
  const h = now.getHours(), m = now.getMinutes();
  
  // 기상청 API 호출 시간 계산
  const base_time = h < 2 ? '2300' : h < 5 ? '0200' : h < 8 ? '0500' : h < 11 ? '0800' : h < 14 ? '1100' : h < 17 ? '1400' : h < 20 ? '1700' : '2000';
  const base_date = h < 2 ? new Date(now - 86400000).toISOString().slice(0, 10).replace(/-/g, '') : dateStr;
  let startHour = m >= 30 ? h + 1 : h;
  if (startHour >= 24) startHour = 0;

  const url = `https://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getVilageFcst?serviceKey=${key}&pageNo=1&numOfRows=1000&dataType=JSON&base_date=${base_date}&base_time=${base_time}&nx=${nx}&ny=${ny}`;
  
  const res = await fetch(url);
  const json = await res.json();
  const items = json.response.body.items.item;

  // 최저/최고 온도
  const tmn = items.find(i => i.category === 'TMN')?.fcstValue || '--';
  const tmx = items.find(i => i.category === 'TMX')?.fcstValue || '--';
  
  // 온도 및 강수확률 데이터
  const temps = items.filter(i => i.category === 'TMP');
  const pops = items.filter(i => i.category === 'POP');
  
  // 현재 온도 표시
  document.getElementById('tempNow').textContent = `${temps[0]?.fcstValue || '--'}°C`;
  document.getElementById('tempRange').textContent = `최저 ${tmn}° / 최고 ${tmx}°`;

  // 시간별 날씨 표시
  const listEl = document.getElementById('hourlyList');
  listEl.innerHTML = '';

  for (let i = 0; i < 8; i++) {
    const hh = (startHour + i * 3) % 24;
    const ft = String(hh).padStart(2, '0') + '00';
    const temp = temps.find(t => t.fcstTime === ft)?.fcstValue || '--';
    const pop = pops.find(p => p.fcstTime === ft)?.fcstValue || '--';
    const sky = items.find(k => k.category === 'SKY' && k.fcstTime === ft)?.fcstValue;
    
    // 하늘 상태에 따른 아이콘
    let icon = '☁️';
    if (sky === '1') icon = '☀️';
    else if (sky === '3') icon = '🌤️';

    const box = document.createElement('div');
    box.className = 'weather-hour-box';
    box.innerHTML = `<div>${hh}시</div><div>${icon}</div><div>${pop}%</div><div>${temp}°</div>`;
    listEl.appendChild(box);
  }

  fadeInCard('weather-card');
}

// 뉴스 불러오기 (팀원 코드 기반)
async function loadNews(gkey, okey) {
  const out = [];
  const topics = ['business', 'technology', 'general'];
  
  for (let t of topics) {
    const r = await fetch(`https://gnews.io/api/v4/top-headlines?lang=en&country=us&topic=${t}&max=10&token=${gkey}`);
    const d = await r.json();
    if (Array.isArray(d.articles)) out.push(...d.articles);
    await new Promise(r => setTimeout(r, 300));
  }
  
  const summaryEl = document.getElementById('news-summary');
  summaryEl.innerHTML = '';
  
  if (!out.length) {
    summaryEl.innerHTML = '<p>뉴스를 불러오지 못했습니다.</p>';
    fadeInCard('news-card');
    return;
  }
  
  const combined = out.map((a, i) => `${i + 1}. ${a.title}\n${a.description || a.content || ''}`).join('\n\n');
  const krTopics = ['경제', '정치', '기술'];
  const emoji = { '경제': '💰', '정치': '🏛️', '기술': '💻' };
  
  for (let t of krTopics) {
    const prompt = `다음은 오늘의 뉴스 기사들입니다. 이 중 "${t}" 분야만 한 문단으로 한국어로 요약해주세요.\n\n${combined}`;
    
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${okey}`
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.5,
        max_tokens: 500
      })
    });
    
    const js = await res.json();
    const sum = js.choices?.[0]?.message?.content || '(요약 실패)';
    
    const block = document.createElement('div');
    block.className = 'news-fadein';
    block.style.background = '#f3f3f3';
    block.style.borderRadius = '10px';
    block.style.padding = '1rem';
    block.style.marginBottom = '1rem';
    block.innerHTML = `<span style="font-weight:bold;display:block;margin-bottom:0.5rem;">${emoji[t]} ${t}</span>${sum}`;
    summaryEl.appendChild(block);
    
    setTimeout(() => block.classList.add('show'), 50);
  }
  
  fadeInCard('news-card');
}

// 히스넷 공지사항 불러오기 (AJAX)
async function loadHisnetNotices() {
  const userid = document.getElementById("userid").value.trim();
  const password = document.getElementById("password").value.trim();
  const department = document.getElementById("department").value;

  if (!userid || !password) {
    showToast("아이디와 비밀번호를 입력해주세요.", true);
    return;
  }

  showLoading();

  try {
    const response = await fetch('/api/hisnet', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        userid: userid,
        password: password,
        department: department
      })
    });

    const data = await response.json();

    if (!data.success) {
      showToast(data.error || "공지사항을 불러오는 데 실패했습니다.", true);
      return;
    }

    // 로그인 정보 저장
    currentLoginData = { userid, password };

    // 로그인 카드 숨기기 (부드럽게)
    const loginCard = document.getElementById("hisnet-login-card");
    loginCard.style.opacity = "0";
    loginCard.style.transform = "translateY(-10px)";
    
    setTimeout(() => {
      loginCard.style.display = "none";
      
      // 공지사항 카드를 같은 자리에 표시
      const noticesCard = document.getElementById("notices-card");
      noticesCard.style.display = "block";
      setTimeout(() => noticesCard.classList.add("show"), 10);
    }, 600); // CSS transition과 맞춤
    
    // 제목 업데이트
    document.getElementById("notices-title").textContent = 
      `${deptIcons[department]} ${department} 공지사항`;
    document.getElementById("department-change").value = department;

    // 공지사항 목록 생성
    const noticeList = document.getElementById("notice-list");
    noticeList.innerHTML = "";

    if (data.links && data.links.length > 0) {
      data.links.forEach((notice) => {
        const li = document.createElement("li");
        li.className = "notice-item";
        li.innerHTML = `
          <button class="notice-btn" data-href="https://hisnet.handong.edu/myboard/${notice.href}">
            ${notice.text}
          </button>
        `;
        noticeList.appendChild(li);
      });

      // 클립보드 복사 이벤트 추가
      addCopyListeners();
    } else {
      noticeList.innerHTML = `
        <div class="empty-state">
          <h3>📋 공지사항이 없습니다</h3>
          <p>현재 ${department}에 등록된 공지사항이 없습니다.</p>
        </div>
      `;
    }

    showToast("공지사항을 성공적으로 불러왔습니다!");

  } catch (error) {
    console.error("히스넷 로딩 실패:", error);
    showToast("공지사항을 불러오는 데 실패했습니다.", true);
  } finally {
    hideLoading();
  }
}

// 학부 변경
async function changeDepartment() {
  const newDept = document.getElementById("department-change").value;
  document.getElementById("department").value = newDept;
  
  // 로그인 정보가 있다면 새로운 학부 공지사항 불러오기
  if (currentLoginData) {
    showLoading();

    try {
      const response = await fetch('/api/hisnet', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userid: currentLoginData.userid,
          password: currentLoginData.password,
          department: newDept
        })
      });

      const data = await response.json();

      if (data.success) {
        // 제목 업데이트
        document.getElementById("notices-title").textContent = 
          `${deptIcons[newDept]} ${newDept} 공지사항`;

        // 공지사항 목록 업데이트
        const noticeList = document.getElementById("notice-list");
        noticeList.innerHTML = "";

        if (data.links && data.links.length > 0) {
          data.links.forEach((notice) => {
            const li = document.createElement("li");
            li.className = "notice-item";
            li.innerHTML = `
              <button class="notice-btn" data-href="https://hisnet.handong.edu/myboard/${notice.href}">
                ${notice.text}
              </button>
            `;
            noticeList.appendChild(li);
          });

          addCopyListeners();
        } else {
          noticeList.innerHTML = `
            <div class="empty-state">
              <h3>📋 공지사항이 없습니다</h3>
              <p>현재 ${newDept}에 등록된 공지사항이 없습니다.</p>
            </div>
          `;
        }
      } else {
        showToast(data.error || "학부 변경에 실패했습니다.", true);
      }
    } catch (error) {
      console.error("학부 변경 실패:", error);
      showToast("학부 변경에 실패했습니다.", true);
    } finally {
      hideLoading();
    }
  }
}

// 클립보드 복사 이벤트 리스너 추가
function addCopyListeners() {
  document.querySelectorAll('.notice-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      const href = this.dataset.href;
      
      navigator.clipboard.writeText(href).then(() => {
        showToast("📋 클립보드에 복사되었습니다!");
      }).catch(err => {
        console.error('복사 실패:', err);
        // 폴백: 텍스트 선택 방식
        const textArea = document.createElement('textarea');
        textArea.value = href;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        showToast("📋 클립보드에 복사되었습니다!");
      });
    });
  });
}

// 페이지 로드 완료 시 초기화
document.addEventListener('DOMContentLoaded', function() {
  console.log("통합 대시보드가 로드되었습니다!");
});