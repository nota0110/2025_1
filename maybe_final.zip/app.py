from flask import Flask, render_template, request, jsonify
from crawler import hisnet_login_and_scrape, departmentCode

app = Flask(__name__)
app.secret_key = "your_secret_key_here"

@app.route("/") #랜딩 페이지 실행시
def dashboard(): #dashboard()실행 = 메인페이지
    return render_template("dashboard.html", departments=departmentCode) #html파일이랑 학부 코드 dict 전송

@app.route("/api/hisnet", methods=["POST"]) #api용 엔드포인트 설정, post 전용
def hisnet_api():
    try:
        data = request.get_json()
        userid = data.get("userid")
        password = data.get("password")
        department = data.get("department")

        if not userid or not password or not department: #입력창 공백시 처리
            return jsonify({
                "success": False,
                "error": "모든 필드를 입력해주세요."
            }), 400

        # 히스넷 크롤링 실행
        links = hisnet_login_and_scrape(userid, password, department) #crawler.py의 함수 호출
        
        return jsonify({
            "success": True,
            "department": department,
            "links": links
        })
        
    except Exception as e:#오류 발생시
        return jsonify({
            "success": False,
            "error": f"크롤링 중 오류가 발생했습니다: {str(e)}"
        }), 500


if __name__ == "__main__":
    app.run(debug=True)