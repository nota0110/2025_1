import requests
from bs4 import BeautifulSoup

departmentCode = {
    "일반공지": "NB0001", "글로벌리더십": "B0020", "국제어문": "B0021",
    "경영경제": "B0022", "법학부": "B0023", "커뮤니케이션": "B0024",
    "상담복지": "B0102", "생명과학": "B0028", "공간환경시스템": "B0025",
    "전산전자": "B0029", "콘텐츠융합디자인": "B0027", "기계제어": "B0026",
    "ICT창업학부": "B0419", "언어교육원": "B0031", "창의융합교육원": "B0427",
    "AI융합교육원": "B0431"
}

def hisnet_login_and_scrape(user_id, user_pw, selected_dept):
    """
    히스넷 로그인 후 선택된 학부의 공지사항을 크롤링하여 반환
    
    Args:
        user_id (str): 히스넷 아이디
        user_pw (str): 히스넷 비밀번호  
        selected_dept (str): 선택된 학부명
        
    Returns:
        list: 공지사항 링크 리스트 [{"text": "제목", "href": "링크"}, ...]
    """
    session = requests.Session()
    headers = {"User-Agent": "Mozilla/5.0"}

    try:
        # 1. 로그인 페이지에서 ID/PW 필드 이름 동적으로 찾기
        login_url = "https://hisnet.handong.edu/login/login.php"
        res = session.get(login_url, headers=headers, timeout=10)
        soup = BeautifulSoup(res.text, "html.parser")
        
        id_input = soup.find("input", {"name": lambda x: x and "id_" in x})
        pw_input = soup.find("input", {"name": lambda x: x and "password_" in x})
        
        if not id_input or not pw_input:
            raise Exception("로그인 폼을 찾을 수 없습니다.")
            
        id_field = id_input["name"]
        pw_field = pw_input["name"]

        # 2. 로그인 시도
        login_data = {
            "part": "",
            "f_name": "",
            "agree": "",
            "Language": "Korean",
            id_field: user_id,
            pw_field: user_pw
        }
        
        login_response = session.post(
            "https://hisnet.handong.edu/login/_login.php", 
            data=login_data, 
            headers=headers,
            timeout=10
        )
        
        # 로그인 성공 여부 간단 체크 (더 정교한 검증 가능)
        if "error" in login_response.text.lower():
            raise Exception("로그인에 실패했습니다. 아이디와 비밀번호를 확인해주세요.")

        # 3. 학부별 공지사항 페이지 접속
        board_code = departmentCode.get(selected_dept, "NB0001")
        board_url = f"https://hisnet.handong.edu/myboard/list.php?Board={board_code}"
        
        res = session.get(board_url, headers=headers, timeout=10)
        soup = BeautifulSoup(res.text, "html.parser")

        # 4. 공지사항 링크 필터링
        links = []
        for a in soup.find_all("a", href=True):
            text = a.get_text(strip=True)
            href = a["href"]
            
            # 불필요한 링크 제외
            if text == "고정공지" or text.isdigit() or not text:
                continue
                
            # 공지사항 링크만 선별
            if not (href.startswith("read.php") and "id=" in href and "Page=" in href and "Board=" in href):
                continue
                
            links.append({"text": text, "href": href})
            
        return links
        
    #에러코드 정리
    except requests.exceptions.Timeout:
        raise Exception("서버 응답 시간이 초과되었습니다.")
    except requests.exceptions.ConnectionError:
        raise Exception("네트워크 연결에 문제가 있습니다.")
    except Exception as e:
        raise Exception(f"크롤링 중 오류 발생: {str(e)}")
    finally:
        session.close()